
NAME='admin'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['admin_plugin']
