NAME='router_rewrite'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_rewrite']
