NAME='alarm_xmpp'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lgloox']
GCC_LIST = ['alarm_xmpp_plugin', 'gloox.cc']
