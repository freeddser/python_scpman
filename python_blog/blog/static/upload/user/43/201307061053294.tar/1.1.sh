#!/bin/sh
#code by scpman
#test 
name='xiaoyi'
echo $name
name="xiaoyi"
echo $name
name=xiaoyi
echo $name
