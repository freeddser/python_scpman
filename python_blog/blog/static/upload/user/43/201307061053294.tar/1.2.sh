#!/bin/sh
#code by scpman
#use for: about a boy and some MM ..
echo 'Many times, the way to work, work on the car, the sky, the earth.'
echo 
echo "I was holding a knife riding on a donkey, rove all over the world code-named $0 swordsman."
echo 
echo 'Spring to autumn, I met a girl, she said she is not small, her name is $1  , then I met a lot of girls, $2 $3 ...'
echo 
echo 'Every time a girl want to and I together into the donkey, I asked, " who are you ...'
